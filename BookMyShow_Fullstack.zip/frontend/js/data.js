// data.js - hard-coded data
const movies = [
  "Suraj par mangal bhari",
  "Tenet",
  "The war with grandpa",
  "The personal history of David Copperfield",
  "Come Play"
];
const slots = [
  "10:00 AM",
  "01:00 PM",
  "03:00 PM",
  "08:00 PM"
];
const seatTypes = ["A1","A2","A3","A4","D1","D2"];
